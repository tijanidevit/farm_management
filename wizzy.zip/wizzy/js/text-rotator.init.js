// ----- TEST-ROTATE ----- //

var a = 0;
$(".text-rotate").textrotator({
    animation: "fade",
    speed: 3500
});