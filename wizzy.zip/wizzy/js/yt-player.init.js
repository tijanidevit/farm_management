// ----- YT-PLAYER ----- //


// YT-video
$(".player").mb_YTPlayer();