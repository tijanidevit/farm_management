<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php 
    if (!isset($_GET['id'])) {
        header('location: departments.php');
    }
    $id = $_GET['id'];
    include_once '../core/session.class.php';
    include_once '../core/departments.class.php';
    $session_obj = new Session();
    $department_obj = new Departments();

    $department = $department_obj->fetch_department($id);
?>
<?php include_once 'fractions/head.php'; ?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper">
        <?php include_once 'fractions/header.php'; ?>
        <?php include_once 'fractions/sidebar.php'; ?>
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0">Departments</h3>
                    <ol class="breadcrumb mb-0 p-0 bg-transparent">
                        <li class="breadcrumb-item"><a href="./">Home</a></li>
                        <li class="breadcrumb-item active">Departments</li>
                    </ol>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Edit department</h4>
                                <h6 class="card-subtitle">Update the details of the department</h6>
                                <div class="mt-4">

                                    <?php 
                                        if (empty($department)) {
                                            echo "<div class='alert alert-danger'> Department not found! Try checking the list of departments <a href='departments.php'>Here</a>";
                                        }
                                        else{
                                    ?>
                                        <form method="post" id="editDeptForm">
                                           <div class="my-5">

                                                <div class="form-group">
                                                    <div id="message"></div>
                                                </div>
                                                <input type="hidden" name="id" value="<?php echo $department['id'] ?>">
                                                <div class="form-group">
                                                    <label>Department Name</label>
                                                    <input type="" name="department" value="<?php echo $department['department'] ?>" class="form-control">
                                                </div> 
                                                <div class="form-group">
                                                    <button class="btn btn-dark">Submit</button>
                                                    <span id="spinner" style="display: none;"> Loading........</span>
                                                </div> 
                                           </div>
                                        </form>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>               
            </div>
            <footer class="footer">
                <?php echo date('Y')?> Human Resources Management System
            </footer>
        </div>
    </div>
    <div class="chat-windows"></div>
</body>

</html>

<?php include_once 'fractions/scripts.php'; ?>

<script>
    $('#editDeptForm').submit(function(e){
        $('#message').fadeOut();
        e.preventDefault();
        $.ajax({
          url:'ajax/edit_department.php',
          type: 'POST',
          data: $('#editDeptForm').serialize(),
          beforeSend: function(){
            $('#spinner').show();
          },
          success: function(data){
            console.log(data);
            if (data == 1) {
                window.location.href = 'departments.php';
            }
            else{
                $('#message').fadeIn();  
                $('#message').html(data);  
                $('#spinner').hide();   
            }       
          }
        })
    })
</script>
