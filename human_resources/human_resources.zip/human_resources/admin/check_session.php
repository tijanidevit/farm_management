<?php 
	include_once '../core/session.class.php';
	$session = new Session();

	if (!$session->check_session('admin')) {
		header('location: ./');
	}
?>