<?php 
    include_once '../core/session.class.php';

    $session = new Session();
    if ($session->check_session('admin')) {
        header('location: dashboard.php');
    }
?>

<!DOCTYPE html>
<html dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Tijani Mustapha">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <title>Human Resources</title>
    <link href="../assets/css/style.min.css" rel="stylesheet">
</head>

<body>
    <div class="main-wrapper">
        <div class="preloader">
            <div class="lds-ripple">
                <div class="lds-pos"></div>
                <div class="lds-pos"></div>
            </div>
        </div>

        <div class="auth-wrapper d-flex no-block justify-content-center align-items-center" style="background:url(../assets/images/background/login-register.jpg) no-repeat center center; background-size: cover;">
            <div class="auth-box p-4 bg-white rounded">
                <div id="loginform">
                    <div class="logo">
                        <h3 class="box-title mb-3">Sign In</h3>
                    </div>
                    <!-- Form -->
                    <div class="row">
                        <div class="col-12">
                            <div id="message" class="alert alert-danger"></div>
                            <form class="form-horizontal mt-3 form-material" method="post" id="loginform">
                                <div class="form-group mb-3">
                                    <div class="">
                                        <input class="form-control" type="text" name="username" id="username" placeholder="Username"> 
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="">
                                        <input class="form-control" type="password" name="password" id="password" placeholder="Password"> 
                                    </div>
                                </div>
                                <div class="form-group text-center mt-4">
                                    <div class="col-xs-12">
                                        <button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" >Log In</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../jquery.js"></script>
    <script src="../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script>
    $('[data-toggle="tooltip"]').tooltip();
    $(".preloader").fadeOut();
    $('#message').fadeOut();
    </script>

    <script>
        $('#loginform').click(function() {
            $('#message').fadeOut();
        })


        $('#loginform').submit(function(e) {
            e.preventDefault();

            $.ajax({
              url:'ajax/login.php',
              type: 'POST',
              data: {username : $('#username').val(),password : $('#password').val() },
              cache: false,
              beforeSend: function(){
                $('#spinner').show();
              },
              success: function(data){
                console.log(data);
                if (data == 1) {
                    window.location.href = 'dashboard.php';
                    $('#message').html(data);
                }
                else{
                    $('#message').show();
                    $('#message').html(data);
                }
              }
            })
        })

        // $('#loginform').submit(function(e) {
        //     e.preventDefault();
        //     //let lf = document.getElementById('loginform');
        //     let formData = $('#loginform').serialize();
        //     fetch('ajax/login.php',{
        //         method: 'Post',
        //         headers:{
        //             'Content-Type' : 'application/json'
        //         },
        //         body: JSON.stringify({
        //             data: formData,
        //         })
        //     })
            
        //     .then(res =>{
        //         if (res.ok) {
        //             console.log(res);
        //         }
        //         else{
        //             console.log('is here');
        //         }
        //     })

        //     .then(data => console.log(data))
        //     .then(error => console.log(error))
        // })
    </script>
</body>

</html>