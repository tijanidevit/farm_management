<?php
	echo fetch_role();
	function fetch_role()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/roles.class.php';
		$role_obj = new roles();
		$session_obj = new Session();

		$department_id = $_POST['department_id'];

		$roles = $role_obj->fetch_department_roles($department_id);

		if (empty($roles)) {
			return 0;
		}
		else{
			foreach ($roles as $row) {
				echo '
					<option value="'.$row["id"].'">'.$row["role"].'</option>
				';
			}
		}
	}
?>

