<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php include_once 'fractions/head.php'; 
    include_once '../core/session.class.php';
    include_once '../core/departments.class.php';
    $department_obj = new Departments();
    $session_obj = new Session();
    $departments = $department_obj->fetch_departments();
?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper">
        <?php include_once 'fractions/header.php'; ?>
        <?php include_once 'fractions/sidebar.php'; ?>
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0">Staffs</h3>
                    <ol class="breadcrumb mb-0 p-0 bg-transparent">
                        <li class="breadcrumb-item"><a href="./">Home</a></li>
                        <li class="breadcrumb-item active">Staffs</li>
                    </ol>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Add new staff</h4>
                                <h6 class="card-subtitle">Supply the details of the staff</h6>
                                <div class="mt-4">
                                    <form method="post" id="addStaffForm" enctype="multipart/form-data">
                                       <div class="my-5">

                                            <div class="form-group">
                                                <div id="message"></div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                    <label>Department</label>
                                                        <select type="" name="department_id" id="departmentId" class="form-control" required>
                                                            <option>Select a department</option>
                                                            <?php foreach ($departments as $department): ?>
                                                                <option value="<?php echo $department['id'] ?>"><?php echo $department['department'] ?></option>
                                                            <?php endforeach ?>
                                                        </select>
                                                    </div> 
                                                    <div class="form-group">
                                                        <label>Role</label>
                                                        <select id="roleId" name="role_id" class="form-control" required>
                                                        </select>
                                                    </div> 
                                                    <div class="form-group">
                                                        <label>Fullname</label>
                                                        <input type="text" name="fullname" id="fullname" required class="form-control">
                                                    </div> 
                                                    <div class="form-group">
                                                        <label>Email Address</label>
                                                        <input type="email" name="email" required class="form-control">
                                                    </div>
                                                </div> 

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Address</label>
                                                        <input type="text" name="address" required class="form-control">
                                                    </div> 
                                                    <div class="form-group">
                                                        <label>Phone Number</label>
                                                        <input type="text" name="phone" id="phoneInp" required class="form-control">
                                                        <small id="phoneHelper"></small>
                                                    </div> 
                                                    <div class="form-group">
                                                        <label>Passport</label>
                                                        <input type="file" accept="image/*" name="passport" required class="form-control">
                                                    </div> 
                                                    <div class="form-group">
                                                        <label>Date of birth</label>
                                                        <input type="date" name="dob" required class="form-control">
                                                    </div>
                                                </div> 
                                                <div class="form-group">
                                                    <button class="btn btn-dark">Submit</button>
                                                    <span id="spinner" style="display: none;"> Loading........</span>
                                                </div> 
                                           </div>
                                       </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>               
            </div>
            <footer class="footer">
                <?php echo date('Y')?> Human Resources Management System
            </footer>
        </div>
    </div>
    <div class="chat-windows"></div>
</body>

</html>

<?php include_once 'fractions/scripts.php'; ?>

<script>
    $('#addStaffForm').submit(function(e){
        $('#message').fadeOut();
        e.preventDefault();
        $.ajax({
          url:'ajax/add_staff.php',
          type: 'POST',
          data: new FormData(this),
          contentType: false,
          processData: false,
          cache: false,
          beforeSend: function(){
            $('#spinner').show();
          },
          success: function(data){
            if (data == 1) 
            {
                $('#message').html('<span class="alert alert-success">'+ $("#fullname").val() +' added successfully </span>');
                $('#addStaffForm')[0].reset();
            }
            else{
                $('#message').html(data);   
            }
            
            $('#message').fadeIn();         
            $('#spinner').hide();
          }
        })
    })

    $('#departmentId').change(function(){
        var department_id = $('#departmentId').val();
        $.ajax({
          url:'ajax/fetch_role_options.php',
          type: 'POST',
          data: {department_id : department_id},
          success: function(data){
            $('#roleId').html(data);  
          }
        })
    })


    $('#phoneInp').keyup(function(){
        var value = $('#phoneInp').val();
        if(isNaN(value)){
            var length = value.length;
            $('#phoneInp').val(value.substr(0,length-1));
            $('#phoneHelper').text('Phone number must be a numerical value');
        }
        else{
            $('#phoneHelper').text('');
        }
    })
</script>

                            
