<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php 
    if (!isset($_GET['id'])) {
        header('location: staffs.php');
    }
    $id = $_GET['id'];
    include_once '../core/session.class.php';
    include_once '../core/staffs.class.php';
    include_once '../core/departments.class.php';
    include_once '../core/roles.class.php';
    $department_obj = new Departments();
    $role_obj = new Roles();
    $session_obj = new Session();
    $staff_obj = new staffs();

    $staff = $staff_obj->fetch_staff($id);
    $role_id = $staff['role_id'];
    $departments = $department_obj->fetch_departments();
    $department_prop = $role_obj->fetch_role_department($role_id);
    $department_id = $department_prop['department_id'];

    $department_roles = $department_obj->fetch_department_roles($department_id);
?>
<?php include_once 'fractions/head.php'; ?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper">
        <?php include_once 'fractions/header.php'; ?>
        <?php include_once 'fractions/sidebar.php'; ?>
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0">Staffs</h3>
                    <ol class="breadcrumb mb-0 p-0 bg-transparent">
                        <li class="breadcrumb-item"><a href="./">Home</a></li>
                        <li class="breadcrumb-item"><a href="staffs.php">Staffs</a></li>
                    </ol>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <?php 
                                    if (empty($staff)) {
                                        echo "<div class='alert alert-danger'> staff not found! Try checking the list of staffs <a href='staffs.php'>Here</a>";
                                    }
                                    else{
                                ?>
                                <h4 class="card-title">Edit staff</h4>
                                <h6 class="card-subtitle">Update the details of the staff</h6>
                                <div class="mt-4">
                                    <div class="my-5">
                                        <div class="row">
                                            <div class="col-md-8 jumbotron">
                                                <h3>Edit Basic Details</h3>

                                                <form method="post" id="editStaffForm">
                                                    <div class="col-12 form-group">
                                                        <div id="message"></div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">

                                                            <div class="form-group">
                                                                <label>Department</label>
                                                                <select type="" name="department_id" id="departmentId" class="form-control" required>
                                                                    <?php foreach ($departments as $department): ?>
                                                                        <option value="<?php echo $department['id'] ?>"><?php echo $department['department'] ?></option>
                                                                    <?php endforeach ?>
                                                                </select>
                                                            </div> 

                                                            <div class="form-group">
                                                                <label>Role</label>
                                                                <select type="" id="roleId" name="role_id" class="form-control" required>
                                                                    <option value="<?php echo $staff['role_id'] ?>"><?php echo $staff['role'] ?></option>
                                                                    <span id="roleOptions"></span>
                                                                </select>
                                                            </div> 

                                                            <input type="hidden" name="id" value="<?php echo $id ?>">

                                                            <div class="form-group">
                                                                <label>Fullname</label>
                                                                <input type="text" name="fullname" value="<?php echo $staff['fullname'] ?>" required class="form-control">
                                                            </div> 
                                                            <div class="form-group">
                                                                <label>Email Address</label>
                                                                <input type="email" name="email" value="<?php echo $staff['email'] ?>" required class="form-control">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>Address</label>
                                                                <input type="text" value="<?php echo $staff['address'] ?>" name="address" required class="form-control">
                                                            </div> 
                                                            <div class="form-group">
                                                                <label>Phone Number</label>
                                                                <input type="text" value="<?php echo $staff['phone'] ?>" name="phone" id="phoneInp" required class="form-control">
                                                                <small id="phoneHelper"></small>
                                                            </div> 
                                                            <div class="form-group">
                                                                <label>Date of birth</label>
                                                                <input type="date" name="dob" value="<?php echo $staff['dob'] ?>" required class="form-control">
                                                            </div>
                                                        </div>

                                                        <div class="col-12 form-group">
                                                            <button class="btn btn-dark">Submit</button>
                                                            <span id="spinner" style="display: none;"> Loading........</span>
                                                        </div> 
                                                    </div>
                                                </form>
                                            </div>


                                            <div class="col-md-3 ml-2 jumbotron">
                                                <h3>Edit Passport</h3>
                                                <form method="post" id="editPassportForm" enctype="multipart/form-data">
                                                    <div class="col-12 form-group">
                                                        <div id="passportMessage"></div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label>Passport <?php echo $staff['passport'] ?></label>
                                                                <input type="file" accept="image/*" name="passport" required class="form-control">
                                                            </div> 
                                                            <input type="hidden" name="id" value="<?php echo $id ?>">
                                                            <input type="hidden" name="old_passport" value="<?php echo $staff['passport'] ?>">

                                                            <div class="col-12 form-group">
                                                                <button class="btn btn-dark">Submit</button>
                                                                <span id="spinner" style="display: none;"> Loading........</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>

                                                <hr>
                                                <h3>Promote Staff</h3>

                                                <div class="col-12 form-group">
                                                    <div id="promotionMessage"></div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <form method="post" id="promotionForm">
                                                             <div class="form-group">
                                                                <label>Role</label>
                                                                <select id="roleId" name="role_id" class="form-control" required>
                                                                    <?php foreach ($department_roles as $role): ?>
                                                                        <option value="<?php echo $role['id'] ?>"><?php echo $role['role'] ?>
                                                                        </option>
                                                                    <?php endforeach ?>
                                                                </select>
                                                            </div> 

                                                            <input type="hidden" name="id" value="<?php echo $id ?>">

                                                            <div class="col-12 form-group">
                                                                <button class="btn btn-dark">Submit</button>
                                                                <span id="spinner" style="display: none;"> Loading........</span>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>

                                        </div> 
                                       </div>
                                    </form>
                                <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>   

                                                            
            </div>
            <footer class="footer">
                <?php echo date('Y')?> Human Resources Management System
            </footer>
        </div>
    </div>
    <div class="chat-windows"></div>
</body>

</html>

<?php include_once 'fractions/scripts.php'; ?>

<script>
    $('#editStaffForm').submit(function(e){
        $('#message').fadeOut();
        e.preventDefault();
        $.ajax({
          url:'ajax/edit_staff.php',
          type: 'POST',
          data: $('#editStaffForm').serialize(),
          beforeSend: function(){
            $('#spinner').show();
          },
          success: function(data){
            console.log(data);
            if (data == 1) {
                window.location.href = 'staffs.php';
            }
            else{
                $('#message').fadeIn();  
                $('#message').html(data);  
                $('#spinner').hide();   
            }       
          }
        })
    })

    $('#editPassportForm').submit(function(e){
        $('#passportMessage').fadeOut();
        e.preventDefault();
        $.ajax({
          url:'ajax/update_staff_passport.php',
          type: 'POST',
          data: new FormData(this),
          contentType: false,
          processData: false,
          cache: false,
          beforeSend: function(){
            $('#spinner').show();
          },
          success: function(data){
            $('#passportMessage').html(data);   
            $('#passportMessage').fadeIn();         
            $('#spinner').hide();
          }
        })
    })


    $('#promotionForm').submit(function(e){
        $('#promotionMessage').fadeOut();
        e.preventDefault();
        $.ajax({
          url:'ajax/promote_staff.php',
          type: 'POST',
          data: $('#promotionForm').serialize(),
          beforeSend: function(){
            $('#spinner').show();
          },
          success: function(data){
            $('#promotionMessage').html(data);   
            $('#promotionMessage').fadeIn();         
            $('#spinner').hide();
          }
        })
    })

    $('#departmentId').change(function(){
        var department_id = $('#departmentId').val();
        $.ajax({
          url:'ajax/fetch_role_options.php',
          type: 'POST',
          data: {department_id : department_id},
          success: function(data){
            $('#roleId').html(data);  
          }
        })
    })

     $('#phoneInp').keyup(function(){
        var value = $('#phoneInp').val();
        if(isNaN(value)){
            var length = value.length;
            $('#phoneInp').val(value.substr(0,length-1));
            $('#phoneHelper').text('Phone number must be a numerical value');
        }
        else{
            $('#phoneHelper').text('');
        }
    })
</script>
