<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php include_once 'fractions/head.php'; 
    include_once '../core/session.class.php';
    include_once '../core/departments.class.php';
    $department_obj = new Departments();
    $session_obj = new Session();
    $departments = $department_obj->fetch_departments();
?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper">
        <?php include_once 'fractions/header.php'; ?>
        <?php include_once 'fractions/sidebar.php'; ?>
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0">Roles</h3>
                    <ol class="breadcrumb mb-0 p-0 bg-transparent">
                        <li class="breadcrumb-item"><a href="./">Home</a></li>
                        <li class="breadcrumb-item active">Roles</li>
                    </ol>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Add new role</h4>
                                <h6 class="card-subtitle">Supply the details of the role</h6>
                                <div class="mt-4">
                                    <form method="post" id="addRoleForm">
                                       <div class="my-5">

                                            <div class="form-group">
                                                <div id="message"></div>
                                            </div>
                                            <div class="form-group">
                                                <label>Department</label>
                                                <select type="" name="department_id" class="form-control" required>
                                                    <?php foreach ($departments as $department): ?>
                                                        <option value="<?php echo $department['id'] ?>"><?php echo $department['department'] ?></option>
                                                    <?php endforeach ?>
                                                </select>
                                            </div> 
                                            <div class="form-group">
                                                <label>Role</label>
                                                <input type="text" name="role" id="role" required class="form-control">
                                            </div> 
                                            <div class="form-group">
                                                <label>Salary</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text">&#8358;</span>
                                                    </div>                                                    
                                                    <input type="text" name="salary" id="salaryInp" required class="form-control">
                                                    <small id="salaryHelper"></small>
                                                </div>
                                            </div> 
                                            <div class="form-group">
                                                <button class="btn btn-dark">Submit</button>
                                                <span id="spinner" style="display: none;"> Loading........</span>
                                            </div> 
                                       </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-8 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Roles</h4>
                                <h6 class="card-subtitle">Select a department to view roles in the department</h6>
                                <div class="mt-4">                                    
                                    <div class="form-group">
                                        <label>Department</label>
                                        <select id="department_id" onchange="fetchRoles()" name="department_id" class="form-control" required>
                                            <option>Select a department</option>
                                            <?php foreach ($departments as $department): ?>
                                                <option value="<?php echo $department['id'] ?>"><?php echo $department['department'] ?></option>
                                            <?php endforeach ?>
                                        </select>
                                    </div>

                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Role</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <div id="deleteArea" class="mb-2" style="display: none;">
                                            <p>Are you sure you want to delete the role?</p>
                                            <button class="btn btn-primary" onclick="closeDeleteArea()">Cancel</button>
                                            <button class="btn btn-danger text-light" onclick="deleteLink()">Delete</button>
                                        </div>
                                        <tbody id="roleTbody"></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>               
            </div>
            <footer class="footer">
                <?php echo date('Y')?> Human Resources Management System
            </footer>
        </div>
    </div>
    <div class="chat-windows"></div>
</body>

</html>

<?php include_once 'fractions/scripts.php'; ?>

<script>
    var roleId;
    var departmentId;
    $('#addRoleForm').submit(function(e){
        $('#message').fadeOut();
        e.preventDefault();
        $.ajax({
          url:'ajax/add_role.php',
          type: 'POST',
          data: $('#addRoleForm').serialize(),
          beforeSend: function(){
            $('#spinner').show();
          },
          success: function(data){
            if (data == 1) 
            {
                $('#message').html('<span class="alert alert-success">'+ $("#role").val() +' added successfully </span>');
                $('#addRoleForm')[0].reset();
            }
            else{
                $('#message').html(data);   
            }
            
            $('#message').fadeIn();         
            $('#spinner').hide();
          }
        })
    })

    $('#salaryInp').keyup(function(){
        var value = $('#salaryInp').val();
        if(isNaN(value)){
            var length = value.length;
            $('#salaryInp').val(value.substr(0,length-1));
            $('#salaryHelper').text('Salary must be a numerical value');
        }
        else{
            $('#salaryHelper').text('');
        }
    })

    function fetchRoles(){
        var department_id = $('#department_id').val();
        if (!isNaN(department_id)) {
            $.ajax({
              url:'ajax/fetch_roles.php',
              type: 'POST',
              data : {department_id : department_id},
              success: function(data){
                if (data != 0) {
                    $('#roleTbody').html(data);
                }
                else{
                    $('#roleTbody').html('<p class="m-3">No role added yet</p>');
                }
                console.log(data);
                $('table').fadeIn();
              }
            })
        }
    }

    function openDeleteArea(id){
        $('#deleteArea').fadeIn();
        roleId = id;
    }

    function deleteLink(){
        $.ajax({
          url:'ajax/delete_role.php',
          type: 'POST',
          data: {id : roleId},
          success: function(data){
            console.log(data);
            if (data == 1) {
                fetchRoles();   
            }
            else{
                $('#message').html(data);     
            }
          }
        })
        closeDeleteArea();
    }

    function closeDeleteArea(){
        $('#deleteArea').fadeOut();
    }
</script>

                            
