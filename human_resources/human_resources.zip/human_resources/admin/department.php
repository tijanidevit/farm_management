<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php 
    if (!isset($_GET['id'])) {
        header('location: departments.php');
    }
    $id = $_GET['id'];
    include_once '../core/session.class.php';
    include_once '../core/departments.class.php';
    $session_obj = new Session();
    $department_obj = new Departments();

    $department = $department_obj->fetch_department($id);
    $department_roles = $department_obj->fetch_department_roles($id);
?>

<?php include_once 'fractions/head.php'; ?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper">
        <?php include_once 'fractions/header.php'; ?>
        <?php include_once 'fractions/sidebar.php'; ?>
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0">Department</h3>
                    <ol class="breadcrumb mb-0 p-0 bg-transparent">
                        <li class="breadcrumb-item"><a href="./">Home</a></li>
                        <li class="breadcrumb-item active">Department</li>
                    </ol>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <?php 
                                    if (empty($department)) {
                                        echo "<div class='alert alert-danger'> Department not found! Try checking the list of departments <a href='departments.php'>Here</a>";
                                    }
                                    else{
                                ?>
                                <h4 class="card-title"><?php echo $department['department'] ?></h4>
                                <h6 class="card-subtitle"><?php echo $department['department'] ?>'s details</h6>
                                <div class="mt-4">
                                    <h4>Roles in <?php echo $department['department'] ?></h4>
                                    <?php if (empty($department_roles)): ?>
                                        <p>No roles added yet to this department</p>
                                    <?php endif ?>

                                    <?php if (!empty($department_roles)): ?>
                                        <?php foreach ($department_roles as $role): ?>
                                            <p><a class="btn btn-info" href="role.php?id=<?php echo $role['id'] ?>"><?php echo $role['role'] ?></a></p>
                                        <?php endforeach ?>
                                    <?php endif ?>

                                    <div>
                                        <p><a class="btn btn-dark" href="add_role.php?department_id=<?php echo $id ?>">Add new role to <?php echo $department['department'] ?></a></p>
                                    </div>
                                </div>

                            <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>               
            </div>
            <footer class="footer">
                <?php echo date('Y')?> Human Resources Management System
            </footer>
        </div>
    </div>
    <div class="chat-windows"></div>
</body>

</html>

<?php include_once 'fractions/scripts.php'; ?>

