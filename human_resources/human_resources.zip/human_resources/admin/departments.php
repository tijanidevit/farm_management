<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php include_once 'fractions/head.php'; ?>
<body onload="fetchDepartments()">
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper">
        <?php include_once 'fractions/header.php'; ?>
        <?php include_once 'fractions/sidebar.php'; ?>
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0">Departments</h3>
                    <ol class="breadcrumb mb-0 p-0 bg-transparent">
                        <li class="breadcrumb-item"><a href="./">Home</a></li>
                        <li class="breadcrumb-item active">Departments</li>
                    </ol>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Add new department</h4>
                                <h6 class="card-subtitle">Supply the details of the department</h6>
                                <div class="mt-4">
                                    <form method="post" id="addDeptForm">
                                       <div class="my-5">

                                            <div class="form-group">
                                                <div id="message"></div>
                                            </div>
                                            <div class="form-group">
                                                <label>Department Name</label>
                                                <input type="" required name="department" class="form-control">
                                            </div> 
                                            <div class="form-group">
                                                <button class="btn btn-dark">Submit</button>
                                                <span id="spinner" style="display: none;"> Loading........</span>
                                            </div> 
                                       </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-8 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Departments</h4>
                                <h6 class="card-subtitle">List of all registered departments</h6>
                                <div class="mt-4">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Department</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <div id="deleteArea" class="mb-2" style="display: none;">
                                            <p>Are you sure you want to delete the department?</p>
                                            <button class="btn btn-primary" onclick="closeDeleteArea()">Cancel</button>
                                            <button class="btn btn-danger text-light" onclick="deleteLink()">Delete</button>
                                        </div>
                                        <tbody id="departmentTbody"></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>               
            </div>
            <footer class="footer">
                <?php echo date('Y')?> Human Resources Management System
            </footer>
        </div>
    </div>
    <div class="chat-windows"></div>
</body>

</html>

<?php include_once 'fractions/scripts.php'; ?>

<script>
    var mainId;
    $('#addDeptForm').submit(function(e){
        $('#message').fadeOut();
        e.preventDefault();
        $.ajax({
          url:'ajax/add_department.php',
          type: 'POST',
          data: $('#addDeptForm').serialize(),
          beforeSend: function(){
            $('#spinner').show();
          },
          success: function(data){
            console.log(data);
            if (data == 1) {
                $('#addDeptForm')[0].reset();
                fetchDepartments();   
            }
            else{
                $('#message').html(data);     
            }
            $('#message').fadeIn();         
            $('#spinner').hide();
          }
        })
    })

    function fetchDepartments(){
        $.ajax({
          url:'ajax/fetch_departments.php',
          type: 'POST',
          beforeSend: function(){
            $('table').fadeOut();
          },
          success: function(data){
            if (data != 0) {
                $('#departmentTbody').html(data);
            }
            else{
                $('#departmentTbody').html('<p class="m-3">No department added yet</p>');
            }
            $('table').fadeIn();
          }
        })
    }

    function openDeleteArea(id){
        $('#deleteArea').fadeIn();
        mainId = id;
    }

    function deleteLink(){
        $.ajax({
          url:'ajax/delete_department.php',
          type: 'POST',
          data: {id : mainId},
          success: function(data){
            console.log(data);
            if (data == 1) {
                fetchDepartments();   
            }
            else{
                $('#message').html(data);     
            }
          }
        })
        closeDeleteArea();
    }

    function closeDeleteArea(){
        $('#deleteArea').fadeOut();
    }
</script>

                            
