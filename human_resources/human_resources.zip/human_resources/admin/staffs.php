<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php include_once 'fractions/head.php'; 
    include_once '../core/session.class.php';
    include_once '../core/departments.class.php';
    $department_obj = new Departments();
    $session_obj = new Session();
    $departments = $department_obj->fetch_departments();
?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper">
        <?php include_once 'fractions/header.php'; ?>
        <?php include_once 'fractions/sidebar.php'; ?>
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0">Staffs</h3>
                    <ol class="breadcrumb mb-0 p-0 bg-transparent">
                        <li class="breadcrumb-item"><a href="./">Home</a></li>
                        <li class="breadcrumb-item active">Staffs</li>
                    </ol>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Staffs</h4>
                                <h6 class="card-subtitle">Select a role to view staffs in the role</h6>
                                <div class="mt-4">                                    
                                    <div class="row mb-5">
                                        <div class="col-lg-4">
                                            <label>Select Department</label>
                                            <select type="" name="department_id" id="departmentId" class="form-control" required>
                                                <option>Select a department</option>
                                                <?php foreach ($departments as $department): ?>
                                                    <option value="<?php echo $department['id'] ?>"><?php echo $department['department'] ?></option>
                                                <?php endforeach ?>
                                            </select>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Select Role</label>
                                                <select id="roleId" name="role_id" onchange="fetchStaffs()" class="form-control" required>
                                                    <option>Select a role</option>
                                                </select>
                                            </div> 
                                        </div>
                                    </div>

                                    <div id="deleteArea" class="mb-2" style="display: none;">
                                        <p>Are you sure you want to delete the staff?</p>
                                        <button class="btn btn-primary" onclick="closeDeleteArea()">Cancel</button>
                                        <button class="btn btn-danger text-light" onclick="deleteStaff()">Delete</button>
                                    </div>
                                    <div id="staffTbody"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>               
            </div>
            <footer class="footer">
                <?php echo date('Y')?> Human Resources Management System
            </footer>
        </div>
    </div>
    <div class="chat-windows"></div>
</body>

</html>

<?php include_once 'fractions/scripts.php'; ?>

<script>
    var staffId;
    $('#departmentId').change(function(){
        $('#staffTbody').fadeOut();
        var department_id = $('#departmentId').val();
        $.ajax({
          url:'ajax/fetch_role_options.php',
          type: 'POST',
          data: {department_id : department_id},
          success: function(data){          
            $('#roleId').html(data);   
          }
        })
    })

    function fetchStaffs(){
        $('#staffTbody').fadeOut();
        var role_id = $('#roleId').val();
        console.log(role_id);
        if (!isNaN(role_id)) {
            $.ajax({
              url:'ajax/fetch_staffs.php',
              type: 'POST',
              data : {role_id : role_id},
              success: function(data){
                if (data != 0) {
                    $('#staffTbody').html(data);
                }
                else{
                    $('#staffTbody').html('<p class="m-3">No staff added yet</p>');
                }
                $('#staffTbody').fadeIn();
              }
            })
        }
    }

    function openDeleteArea(id){
        $('#deleteArea').fadeIn();
        staffId = id;
    }

    function deleteStaff(){
        $.ajax({
          url:'ajax/delete_staff.php',
          type: 'POST',
          data: {id : staffId},
          success: function(data){
            console.log(data);
            if (data == 1) {
                fetchStaffs();   
            }
            else{
                $('#message').html(data);     
            }
          }
        })
        closeDeleteArea();
    }

    function closeDeleteArea(){
        $('#deleteArea').fadeOut();
    }
</script>

                            
