<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php include_once 'fractions/head.php'; 
    if (!isset($_GET['department_id'])) {
        header('location: roles.php');
    }
    $department_id = $_GET['department_id'];
    include_once '../core/session.class.php';
    include_once '../core/departments.class.php';
    $session_obj = new Session();
    $department_obj = new Departments();
    $department = $department_obj->fetch_department($department_id);
?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper">
        <?php include_once 'fractions/header.php'; ?>
        <?php include_once 'fractions/sidebar.php'; ?>
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0">Roles</h3>
                    <ol class="breadcrumb mb-0 p-0 bg-transparent">
                        <li class="breadcrumb-item"><a href="./">Home</a></li>
                        <li class="breadcrumb-item active">Roles</li>
                    </ol>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-body">

                                <?php if (empty($department)): ?>
                                    <div class='alert alert-danger'> Department not found! Try checking the list of departments <a href='departments.php'>Here</a>
                                <?php endif ?>

                                <?php if (!empty($department)): ?>
                                <h4 class="card-title">Add new role to <?php echo $department['department'] ?></h4>
                                <h6 class="card-subtitle">Supply the details of the role</h6>
                                <div class="mt-4">
                                    <form method="post" id="addRoleForm">
                                       <div class="my-5">

                                            <div class="form-group">
                                                <div id="message"></div>
                                            </div>
                                            <input type="hidden" name="department_id" value="<?php echo $department_id ?>">
                                            <div class="form-group">
                                                <label>Role</label>
                                                <input type="text" name="role" required class="form-control">
                                            </div> 
                                            <div class="form-group">
                                                <label>Salary</label>
                                                <input type="text" name="salary" id="salaryInp" required class="form-control">
                                                <small id="salaryHelper"></small>
                                            </div> 
                                            <div class="form-group">
                                                <button class="btn btn-dark">Submit</button>
                                                <span id="spinner" style="display: none;"> Loading........</span>
                                            </div> 
                                       </div>
                                    </form>
                                </div>
                                <?php endif ?>
                            </div>
                        </div>
                    </div>
                </div>               
            </div>
            <footer class="footer">
                <?php echo date('Y')?> Human Resources Management System
            </footer>
        </div>
    </div>
    <div class="chat-windows"></div>
</body>

</html>

<?php include_once 'fractions/scripts.php'; ?>

<script>
    $('#addRoleForm').submit(function(e){
        $('#message').fadeOut();
        e.preventDefault();
        $.ajax({
          url:'ajax/add_role.php',
          type: 'POST',
          data: $('#addRoleForm').serialize(),
          beforeSend: function(){
            $('#spinner').show();
          },
          success: function(data){ 
            $('#message').fadeIn();  
            $('#message').html(data);         
            $('#spinner').hide();
          }
        })
    })

    $('#salaryInp').keyup(function(){
        var value = $('#salaryInp').val();
        if(isNaN(value)){
            var length = value.length;
            $('#salaryInp').val(value.substr(0,length-1));
            $('#salaryHelper').text('Salary must be a numerical value');
        }
        else{
            $('#salaryHelper').text('');
        }
    })
</script>

                            
