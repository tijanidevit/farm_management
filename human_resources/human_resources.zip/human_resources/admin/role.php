<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php 
    if (!isset($_GET['id'])) {
        header('location: roles.php');
    }
    $id = $_GET['id'];
    include_once '../core/session.class.php';
    include_once '../core/roles.class.php';
    $session_obj = new Session();
    $role_obj = new roles();

    $role = $role_obj->fetch_role($id);
    $role_staffs = $role_obj->fetch_role_staffs($id);
?>

<?php include_once 'fractions/head.php'; ?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper">
        <?php include_once 'fractions/header.php'; ?>
        <?php include_once 'fractions/sidebar.php'; ?>
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0"><?php echo $role['role'] ?></h3>
                    <ol class="breadcrumb mb-0 p-0 bg-transparent">
                        <li class="breadcrumb-item"><a href="./">Home</a></li>
                        <li class="breadcrumb-item"><a href="roles.php">Roles</a></li>
                        <li class="breadcrumb-item active"><?php echo $role['role'] ?></li>
                    </ol>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <?php 
                                    if (empty($role)) {
                                        echo "<div class='alert alert-danger'> role not found! Try checking the list of roles <a href='roles.php'>Here</a>";
                                    }
                                    else{
                                ?>
                                <h4 class="card-title"><?php echo $role['role'] ?></h4>
                                <h6 class="card-subtitle"><?php echo $role['role'] ?>'s details</h6>

                                <table class="table table-bordered">
                                    <tr>
                                        <td>Role</td>
                                        <td><?php echo $role['role'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>Department</td>
                                        <td><?php echo $role['department'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>Salary</td>
                                        <td><?php echo $role['salary'] ?></td>
                                    </tr>
                                </table>
                                <div class="mt-4">
                                    <?php if (empty($role_staffs)): ?>
                                        <p>No staffs added yet to this role</p>
                                    <?php endif ?>

                                    <?php if (!empty($role_staffs)): ?>
                                        <?php foreach ($role_staffs as $staff): ?>
                                            <p><a class="btn btn-info" href="staff.php?id=<?php echo $staff['id'] ?>"><?php echo $staff['staff'] ?></a></p>
                                        <?php endforeach ?>
                                    <?php endif ?>

                                    <div>
                                        <p><a class="btn btn-dark" href="add_staff.php?staff_id=<?php echo $id ?>">Add new staff to <?php echo $role['role'] ?></a></p>
                                    </div>
                                </div>

                            <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>               
            </div>
            <footer class="footer">
                <?php echo date('Y')?> Human Resources Management System
            </footer>
        </div>
    </div>
    <div class="chat-windows"></div>
</body>

</html>

<?php include_once 'fractions/scripts.php'; ?>

<script>
</script>
