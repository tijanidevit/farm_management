<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php 
    if (!isset($_GET['id'])) {
        header('location: roles.php');
    }
    $id = $_GET['id'];
    include_once '../core/session.class.php';
    include_once '../core/roles.class.php';
    include_once '../core/departments.class.php';
    $department_obj = new Departments();
    $session_obj = new Session();
    $role_obj = new Roles();

    $role = $role_obj->fetch_role($id);
    $departments = $department_obj->fetch_departments($id);
?>
<?php include_once 'fractions/head.php'; ?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper">
        <?php include_once 'fractions/header.php'; ?>
        <?php include_once 'fractions/sidebar.php'; ?>
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0">roles</h3>
                    <ol class="breadcrumb mb-0 p-0 bg-transparent">
                        <li class="breadcrumb-item"><a href="./">Home</a></li>
                        <li class="breadcrumb-item"><a href="roles.php">Roles</a></li>
                    </ol>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <?php 
                                    if (empty($role)) {
                                        echo "<div class='alert alert-danger'> role not found! Try checking the list of roles <a href='roles.php'>Here</a>";
                                    }
                                    else{
                                ?>
                                <h4 class="card-title">Edit role</h4>
                                <h6 class="card-subtitle">Update the details of the role</h6>
                                <div class="mt-4">
                                    <form method="post" id="editRoleForm">
                                       <div class="my-5">

                                            <div class="form-group">
                                                <div id="message"></div>
                                            </div>

                                            <div class="form-group">
                                                <label>Department</label>
                                                <select type="" name="department_id" class="form-control" required>
                                                    <option value="<?php echo $role['department_id'] ?>"><?php echo $role['department'] ?></option>
                                                    <?php foreach ($departments as $department): ?>
                                                        <option value="<?php echo $department['id'] ?>"><?php echo $department['department'] ?></option>
                                                    <?php endforeach ?>
                                                </select>
                                            </div> 
                                            <input type="hidden" name="id" value="<?php echo $id ?>">
                                            <div class="form-group">
                                                <label>Role</label>
                                                <input type="" name="role" value="<?php echo $role['role'] ?>" class="form-control">
                                            </div> 
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text">&#8358;</span>
                                                    </div>                                                    
                                                    <input type="text" name="salary" value="<?php echo $role['salary'] ?>" id="salaryInp" required class="form-control">
                                                    <small id="salaryHelper"></small>
                                                </div>
                                            </div> 
                                            <div class="form-group">
                                                <button class="btn btn-dark">Submit</button>
                                                <span id="spinner" style="display: none;"> Loading........</span>
                                            </div> 
                                       </div>
                                    </form>
                                <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>               
            </div>
            <footer class="footer">
                <?php echo date('Y')?> Human Resources Management System
            </footer>
        </div>
    </div>
    <div class="chat-windows"></div>
</body>

</html>

<?php include_once 'fractions/scripts.php'; ?>

<script>
    $('#editRoleForm').submit(function(e){
        $('#message').fadeOut();
        e.preventDefault();
        $.ajax({
          url:'ajax/edit_role.php',
          type: 'POST',
          data: $('#editRoleForm').serialize(),
          beforeSend: function(){
            $('#spinner').show();
          },
          success: function(data){
            console.log(data);
            if (data == 1) {
                window.location.href = 'roles.php';
            }
            else{
                $('#message').fadeIn();  
                $('#message').html(data);  
                $('#spinner').hide();   
            }       
          }
        })
    })
     $('#salaryInp').keyup(function(){
        var value = $('#salaryInp').val();
        if(isNaN(value)){
            var length = value.length;
            $('#salaryInp').val(value.substr(0,length-1));
            $('#salaryHelper').text('Salary must be a numerical value');
        }
        else{
            $('#salaryHelper').text('');
        }
    })
</script>
