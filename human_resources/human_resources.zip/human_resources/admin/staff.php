<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php 
    if (!isset($_GET['id'])) {
        header('location: staffs.php');
    }
    $id = $_GET['id'];
    include_once '../core/session.class.php';
    include_once '../core/staffs.class.php';
    $session_obj = new Session();
    $staff_obj = new Staffs();

    $staff = $staff_obj->fetch_staff($id);
?>

<?php include_once 'fractions/head.php'; ?>
<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper">
        <?php include_once 'fractions/header.php'; ?>
        <?php include_once 'fractions/sidebar.php'; ?>
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0"><?php echo $staff['fullname'] ?></h3>
                    <ol class="breadcrumb mb-0 p-0 bg-transparent">
                        <li class="breadcrumb-item"><a href="./">Home</a></li>
                        <li class="breadcrumb-item"><a href="staffs.php">Staffs</a></li>
                        <li class="breadcrumb-item active"><?php echo $staff['fullname'] ?></li>
                    </ol>
                </div>
            </div>
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <?php 
                                    if (empty($staff)) {
                                        echo "<div class='alert alert-danger'> staff not found! Try checking the list of staffs <a href='staffs.php'>Here</a>";
                                    }
                                    else{
                                ?>
                                <h4 class="card-title"><?php echo $staff['fullname'] ?></h4>
                                <h6 class="card-subtitle"><?php echo $staff['fullname'] ?>'s details</h6>
                                <div class="row">
                                    <div class="col-md-8 col-sm-12">
                                        <table class="table table-bordered">
                                            <tr>
                                                <td>staff</td>
                                                <td><?php echo $staff['fullname'] ?></td>
                                            </tr>
                                            <tr>
                                                <td>Role</td>
                                                <td><?php echo $staff['role'] ?></td>
                                            </tr>
                                            <tr>
                                                <td>Salary</td>
                                                <td>&#8358;<?php echo $staff['salary'] ?></td>
                                            </tr>
                                            <tr>
                                                <td>Email Address</td>
                                                <td><?php echo $staff['email'] ?></td>
                                            </tr>
                                            <tr>
                                                <td>Address</td>
                                                <td><?php echo $staff['address'] ?></td>
                                            </tr>
                                            <tr>
                                                <td>Date of birth</td>
                                                <td><?php echo $staff['dob'] ?></td>
                                            </tr>
                                            <tr>
                                                <td>Phone Number</td>
                                                <td><?php echo $staff['phone'] ?></td>
                                            </tr>
                                        </table>
                                    </div>

                                    <div class="col-md-4 col-sm-12">
                                        <div class="el-card-item pb-3">
                                            <div class="el-card-avatar mb-3 el-overlay-1 w-100 overflow-hidden position-relative text-center"> <img src="../staff_image/<?php echo $staff['passport'] ?>" class="d-block position-relative w-100" alt="<?php echo $staff['fullname'] ?>">
                                            </div>                                            
                                        </div>
                                    </div>
                                </div>
                                <p>To be added later:
                                    <ul>
                                        <li>Staffs Promotion Records</li>
                                        <li>Staffs Leave Records</li>
                                    </ul>
                                </p>
                            <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>               
            </div>
            <footer class="footer">
                <?php echo date('Y')?> Human Resources Management System
            </footer>
        </div>
    </div>
    <div class="chat-windows"></div>
</body>

</html>

<?php include_once 'fractions/scripts.php'; ?>

<script>
</script>
