<?php
	echo add_role();
	function add_role()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/roles.class.php';
		$role_obj = new Roles();
		$session_obj = new Session();

		$role = $_POST['role'];
		$department_id = $_POST['department_id'];
		$salary = $_POST['salary'];

		if ($role_obj->check_role_existence($role,$department_id,$salary)) {
			return '<span class="alert alert-warning">'.$role.' already added </span>';
		}

		if ($role_obj->add_role($role,$department_id,$salary)) {
			return 1;
		}
		else{
			return '<span class="alert alert-danger">Error With Server</span>';
		}
	}
?>