<?php

	echo edit_role();
	function edit_role()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/roles.class.php';
		$role_obj = new roles();
		$session_obj = new Session();

		$role = $_POST['role'];
		$department_id = $_POST['department_id'];
		$salary = $_POST['salary'];
		$id = $_POST['id'];

		
		if ($role_obj->check_edit_role_existence($role,$id,$department_id)) {
			return '<span class="alert alert-warning">'.$role.' already added </span>';
		}

		if ($role_obj->update_role($department_id,$role,$salary,$id)) {
			return 1;
		}
		else{
			return '<span class="alert alert-danger">Error With Server</span>';
		}
	}
?>