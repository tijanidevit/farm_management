<?php
	echo fetch_role();
	function fetch_role()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/staffs.class.php';
		$role_obj = new Staffs();
		$session_obj = new Session();

		$role_id = $_POST['role_id'];

		$staffs = $role_obj->fetch_role_staffs($role_id);

		if (empty($staffs)) {
			return 0;
		}
		else{
			echo '<div class="row">';
			foreach ($staffs as $row) {
				echo '
					<div class="col-md-3 col-6">
                        <div class="card bg-secondary">
                            <div class="el-card-item pb-3">
                                <div class="el-card-avatar mb-3 el-overlay-1 w-100 overflow-hidden position-relative text-center"> <img style="max-height:200px;min-height:200px;" src="../staff_image/'.$row['passport'].'" class="d-block position-relative w-100" alt="user">
                                </div>
                                <div class="el-card-content text-center">
                                    <h4 class="mb-0 text-light">'.$row['fullname'].'</h4> <span class="text-muted">'.$row['role'].'</span>
                                </div>

                        
	                            <div class="row p-3">
									<div class="col-12">
										<a class="btn btn-success btn-sm" href="staff.php?id='.$row['id'].'">View</a>
										<a class="btn btn-warning btn-sm" href="edit_staff.php?id='.$row['id'].'">Edit</a>
										<button class="btn btn-danger btn-sm" onclick="openDeleteArea('.$row['id'].')">Delete</button>
									</div>	
								</div>
                            </div>
                        </div>
                    </div>
				';
			}
			echo "</div>";
		}
	}
?>

