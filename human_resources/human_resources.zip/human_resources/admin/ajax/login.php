<?php
	include_once '../../core/session.class.php';
	include_once '../../core/admin.class.php';
	$admin_obj = new Admin();
	$session_obj = new Session();

	$username = $_POST['username'];
	$password = md5($_POST['password']);

	if ($admin_obj->admin_login($username,$password)) {
		$session_obj->create_session('admin',$username);
		echo 1;
	}
	else{
		echo "Invalid Credentials";
	}
?>