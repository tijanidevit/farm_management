<?php
	echo add_staff();
	function add_staff()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/staffs.class.php';
		$staff_obj = new Staffs();

		$role_id = $_POST['role_id'];

		// return ($role_id);
		$id = $_POST['id'];

		if ($staff_obj->check_promote_role($role_id,$id)) {
			return '<span class="">You cannot promote a staff to his current role </span>';
		}
		
		if ($staff_obj-> promote_staff($role_id,$id)) {
			return '<span class="alert alert-success">Staff promoted succcessfuly</span>';
		}
		else{
			return '<span class="alert alert-danger">Error With Server</span>';
		}
	}

?>