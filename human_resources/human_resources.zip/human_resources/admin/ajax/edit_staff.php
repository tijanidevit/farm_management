<?php
	echo add_staff();
	function add_staff()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/staffs.class.php';
		$staff_obj = new Staffs();

		$fullname = $_POST['fullname'];
		$role_id = $_POST['role_id'];
		$email = $_POST['email'];
		$address = $_POST['address'];
		$dob = $_POST['dob'];
		$phone = $_POST['phone'];
		$id = $_POST['id'];

		if ($staff_obj->check_edit_email($email,$id)) {
			return '<span class="alert alert-warning">A staff with email "'.$email.'" already added </span>';
		}
		
		if ($staff_obj->update_staff($role_id,$email,$fullname,$address,$dob,$phone,$id)) {
			return 1;
		}
		else{
			return '<span class="alert alert-danger">Error With Server</span>';
		}
	}

?>