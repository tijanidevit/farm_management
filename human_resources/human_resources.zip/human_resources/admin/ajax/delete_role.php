<?php

	echo delete_role();
	function delete_role()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/roles.class.php';
		$role_obj = new Roles();
		$session_obj = new Session();

		$id = $_POST['id'];

		if ($role_obj->delete_role($id)) {
			return 1;
		}
		else{
			return '<span class="alert alert-danger">Error With Server</span>';
		}
	}
?>