<?php
	echo add_staff();

	$name = ''; $type = ''; $size = ''; $error = '';
	function add_staff()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/staffs.class.php';
		$staff_obj = new Staffs();

		$fullname = $_POST['fullname'];
		$role_id = $_POST['role_id'];
		$email = $_POST['email'];
		$address = $_POST['address'];
		$dob = $_POST['dob'];
		$phone = $_POST['phone'];
		// $password = $_POST['password'];
		$password = 'password';
		$passport =  $email.'.jpg';


		if ($staff_obj->check_email($email)) {
			return '<span class="alert alert-warning">A staff with email "'.$email.'" already added </span>';
		}


		if ($_FILES["passport"]["error"] > 0) {
    		return $_FILES["passport"]["error"];
		} 
		else if (($_FILES["passport"]["type"] == "image/gif") || ($_FILES["passport"]["type"] == "image/jpeg") || 
			($_FILES["passport"]["type"] == "image/png") || 
			($_FILES["passport"]["type"] == "image/pjpeg"))
		{

			$url = '../../staff_image/'.$email.'.jpg';

			$filename = compress_image($_FILES["passport"]["tmp_name"], $url, 80);
			$buffer = file_get_contents($url);

			/* Force download dialog... */
			header("Content-Type: application/force-download");
			header("Content-Type: application/octet-stream");
			header("Content-Type: application/download");

			/* Don't allow caching... */
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");

			/* Set data type, size and filename */
			header("Content-Type: application/octet-stream");
			header("Content-Transfer-Encoding: binary");
			header("Content-Length: " . strlen($buffer));
			header("Content-Disposition: attachment; filename=$url");

			/* Send our file... */
			$e = $buffer;
		}else {
    			$error = "Uploaded image should be jpg or gif or png";
		}

		if ($staff_obj->add_staff($role_id,$email,$fullname,$address,$dob,$phone,$passport,$password)) {
			return 1;
		}
		else{
			return '<span class="alert alert-danger">Error With Server</span>';
		}
	}

	function compress_image($source_url, $destination_url, $quality) {

		$info = getimagesize($source_url);

    		if ($info['mime'] == 'image/jpeg')
        			$image = imagecreatefromjpeg($source_url);

    		elseif ($info['mime'] == 'image/gif')
        			$image = imagecreatefromgif($source_url);

   		elseif ($info['mime'] == 'image/png')
        			$image = imagecreatefrompng($source_url);

    		imagejpeg($image, $destination_url, $quality);
		return $destination_url;
	}
?>