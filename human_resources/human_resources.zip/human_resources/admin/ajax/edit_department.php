<?php

	echo edited_department();
	function edited_department()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/departments.class.php';
		$department_obj = new Departments();
		$session_obj = new Session();

		$department = $_POST['department'];
		$id = $_POST['id'];

		if ($department_obj->check_department_existence($department)) {
			return '<span class="alert alert-warning">'.$department.' already taken </span>';
		}

		if ($department_obj->update_department($department,$id)) {
			return 1;
		}
		else{
			return '<span class="alert alert-danger">Error With Server</span>';
		}
	}
?>