<?php
	$name = ''; $type = ''; $size = ''; $error = '';
	echo update_passport();
	function update_passport()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/staffs.class.php';
		$staff_obj = new Staffs();

		$id = $_POST['id'];
		$old_passport = $_POST['old_passport'];

		//return $old_passport;

		if ($_FILES["passport"]["error"] > 0) {
    		return $_FILES["passport"]["error"];
		} 
		else if (($_FILES["passport"]["type"] == "image/gif") || ($_FILES["passport"]["type"] == "image/jpeg") || 
			($_FILES["passport"]["type"] == "image/png") || 
			($_FILES["passport"]["type"] == "image/pjpeg"))
		{

			$url = '../../staff_image/'.$old_passport;

			$filename = compress_image($_FILES["passport"]["tmp_name"], $url, 80);
			$buffer = file_get_contents($url);

			/* Force download dialog... */
			header("Content-Type: application/force-download");
			header("Content-Type: application/octet-stream");
			header("Content-Type: application/download");

			/* Don't allow caching... */
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");

			/* Set data type, size and filename */
			header("Content-Type: application/octet-stream");
			header("Content-Transfer-Encoding: binary");
			header("Content-Length: " . strlen($buffer));
			header("Content-Disposition: attachment; filename=$url");

			/* Send our file... */
			$e = $buffer;
		}else {
    			$error = "Uploaded image should be jpg or gif or png";
		}
		
		if ($staff_obj->update_passport($old_passport,$id)) {
			return '<span class="alert alert-success">Passport updated successfully</span>';
		}
		else{
			return '<span class="alert alert-danger">Error With Server</span>';
		}
	}

	function compress_image($source_url, $destination_url, $quality) {

		$info = getimagesize($source_url);

    		if ($info['mime'] == 'image/jpeg')
        			$image = imagecreatefromjpeg($source_url);

    		elseif ($info['mime'] == 'image/gif')
        			$image = imagecreatefromgif($source_url);

   		elseif ($info['mime'] == 'image/png')
        			$image = imagecreatefrompng($source_url);

    		imagejpeg($image, $destination_url, $quality);
		return $destination_url;
	}

?>