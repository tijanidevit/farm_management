<?php

	echo fetch_department();
	function fetch_department()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/departments.class.php';
		$department_obj = new Departments();
		$session_obj = new Session();

		$departments = $department_obj->fetch_departments();

		if (empty($departments)) {
			return 0;
		}
		else{
			foreach ($departments as $row) {
				echo '
					<tr>
						<td>'.$row['department'].'</td>
						<td>
							<a class="btn btn-info text-light btn-sm" href="department.php?id='.$row['id'].'">View</a>
							<a class="btn btn-warning text-light btn-sm" href="edit_department.php?id='.$row['id'].'">Edit</a>
							<button type="button" class="btn btn-danger text-light btn-sm" onclick="openDeleteArea('.$row['id'].')" >Delete</a>
						</td>
					</tr>
				';
			}
		}
	}
?>

