<?php

	echo delete_department();
	function delete_department()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/departments.class.php';
		$department_obj = new Departments();
		$session_obj = new Session();

		$id = $_POST['id'];

		if ($department_obj->delete_department($id)) {
			return 1;
		}
		else{
			return '<span class="alert alert-danger">Error With Server</span>';
		}
	}
?>