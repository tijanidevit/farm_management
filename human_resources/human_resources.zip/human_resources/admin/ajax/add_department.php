<?php

	echo add_department();
	function add_department()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/departments.class.php';
		$department_obj = new Departments();
		$session_obj = new Session();

		$department = $_POST['department'];

		if ($department_obj->check_department_existence($department)) {
			return '<span class="alert alert-warning">'.$department.' already added </span>';
		}

		if ($department_obj->add_department($department)) {
			return 1;
		}
		else{
			return '<span class="alert alert-danger">Error With Server</span>';
		}
	}
?>