<?php
	echo fetch_role();
	function fetch_role()
	{
		include_once '../../core/session.class.php';
		include_once '../../core/roles.class.php';
		$role_obj = new roles();
		$session_obj = new Session();

		$department_id = $_POST['department_id'];

		$roles = $role_obj->fetch_department_roles($department_id);

		if (empty($roles)) {
			return 0;
		}
		else{
			foreach ($roles as $row) {
				echo '
					<tr>
						<td>'.$row['role'].'</td>
						<td>
							<a class="btn btn-info text-light btn-sm" href="role.php?id='.$row['id'].'">View</a>
							<a class="btn btn-warning text-light btn-sm" href="edit_role.php?id='.$row['id'].'">Edit</a>
							<button type="button" class="btn btn-danger text-light btn-sm" onclick="openDeleteArea('.$row['id'].')" >Delete</button>
						</td>
					</tr>
				';
			}
		}
	}
?>

