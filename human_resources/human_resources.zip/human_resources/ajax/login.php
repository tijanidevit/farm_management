<?php
	include_once '../core/session.class.php';
	include_once '../core/staffs.class.php';
	$staff_obj = new Staffs();
	$session_obj = new Session();

	$email = $_POST['email'];
	$password = $_POST['password'];

	if ($staff_obj->staff_login($email,$password)) {
		$session_obj->create_session('staff',$email);
		echo 1;
	}
	else{
		echo "<div class='alert alert-danger'>Invalid Credentials</div>";
	}
?>