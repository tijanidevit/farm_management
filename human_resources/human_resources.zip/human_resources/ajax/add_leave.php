<?php
	echo addleave();
	function addleave()
	{
		include_once '../core/leaves.class.php';
		$leave_obj = new Leaves();

		$staff_id = $_POST['staff_id'];
		$leave_type_id = $_POST['leave_type_id'];
		$start_date = $_POST['start_date'];
		$end_date = $_POST['end_date'];
		if ($leave_obj->check_leave_existence($staff_id,$start_date)) {
			return "<div class='alert alert-warning'>You have recently applied for a leave starting on this day ".$start_date."</div>";
		}

		if ($leave_obj->add_leave($staff_id,$leave_type_id,$start_date,$end_date)) {
			return 1;
		}
		else{
			return "<div class='alert alert-danger'>Server Error</div>";
		}
	}
?>