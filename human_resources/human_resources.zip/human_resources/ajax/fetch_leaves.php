<?php
	echo fetchleave();
	function fetchleave()
	{
		include_once '../core/leaves.class.php';
		$leave_obj = new Leaves();

		$staff_id = $_POST['staff_id'];

		$leaves = $leave_obj->fetch_staff_leaves($staff_id);
		//return var_dump($leaves);
		foreach ($leaves as $leave) {
			if ($leave['status'] == 0) {
				$status = '<td class="alert alert-warning"> Pending </td>';
			}
			if ($leave['status'] == 1) {
				$status = '<td class="alert alert-success"> Approved </td>';
			}
			if ($leave['status'] == 2) {
				$status = '<td class="alert alert-danger"> Declined </td>';
			}
			echo 
				'<tr>
					<td>'.$leave["leave_type"].'</td>
					'.$status.'
					<td>'.$leave["created_at"].'</td>
					<td>'.$leave["start_date"].'</td>
					<td>'.$leave["end_date"].'</td>
				</tr>';
		}
	}
?>